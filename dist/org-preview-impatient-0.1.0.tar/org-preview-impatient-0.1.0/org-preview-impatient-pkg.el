;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-preview-impatient" "0.1.0"
  "Smooth, impatient Org-mode preview in browser."
  '((emacs          "27.1")
    (async          "1.9.4")
    (simple-httpd   "1.5.1")
    (impatient-mode "1.1.0"))
  :url "https://github.com/4honor/org-preview-impatient"
  :keywords '("org" "preview" "impatient" "html"))
